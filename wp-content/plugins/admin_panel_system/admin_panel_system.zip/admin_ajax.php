<?php 

	$r = array("r" => false, "m" => "Acceso denegado");
	if ( isset($_REQUEST) ){

		if(isset($_REQUEST["CDB_INV"])){
			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			global $wpdb, $charset_collate;
			
			///Productos
			$inv_productos = $wpdb->prefix . "inv_productos";
			if($wpdb->get_var("SHOW TABLES LIKE '$inv_productos'") != $inv_productos) {
				dbDelta(  
				  "CREATE TABLE $inv_productos (
				    `id` bigint(20) AUTO_INCREMENT NOT NULL,
				    `sku` varchar(255) NOT NULL DEFAULT '',
				    `coste` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `beneficio` int(20) NOT NULL DEFAULT '0',
				    `user` bigint(20) NOT NULL DEFAULT '0',
				    `data_extra` text(0) NOT NULL DEFAULT '',
				    PRIMARY KEY (`id`)
				  ) $charset_collate;"
				);
			}else{
				$wpdb->query( "ALTER TABLE $inv_productos ADD COLUMN IF NOT EXISTS pdc_siva DECIMAL(10,2) NOT NULL DEFAULT '0'" );
				$wpdb->query( "ALTER TABLE $inv_productos ADD COLUMN IF NOT EXISTS iva int(10) NOT NULL DEFAULT '0'" );
				$wpdb->query( "ALTER TABLE $inv_productos ADD COLUMN IF NOT EXISTS pdc_civa DECIMAL(10,2) NOT NULL DEFAULT '0'" );
				$wpdb->query( "ALTER TABLE $inv_productos ADD COLUMN IF NOT EXISTS preparacion DECIMAL(10,2) NOT NULL DEFAULT '0'" );
				$wpdb->query( "ALTER TABLE $inv_productos ADD COLUMN IF NOT EXISTS transporte DECIMAL(10,2) NOT NULL DEFAULT '0'" );
				$wpdb->query( "ALTER TABLE $inv_productos ADD COLUMN IF NOT EXISTS otros DECIMAL(10,2) NOT NULL DEFAULT '0'" );	

			}

			////Operaciones
			$inv_operaciones = $wpdb->prefix . "inv_operaciones";
			if($wpdb->get_var("SHOW TABLES LIKE '$inv_operaciones'") != $inv_operaciones) {
				dbDelta(  
				  "CREATE TABLE $inv_operaciones (
				    `id` bigint(20) AUTO_INCREMENT NOT NULL,
				    `sku` varchar(255) NOT NULL DEFAULT '',
				    `orden` varchar(255) NOT NULL DEFAULT '',
				    `fecha` DATETIME NOT NULL,
				    `cantidad` int(20) NOT NULL DEFAULT '0',
				    `base` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `iva` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `fba` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `amz` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `user` bigint(20) NOT NULL DEFAULT '0',
				    `compra` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `beneficio` int(20) NOT NULL DEFAULT '0',
				    `beneficio_user` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `beneficio_total` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `tienda` varchar(255) NOT NULL DEFAULT '',
				    `data_extra` text(0) NOT NULL DEFAULT '',
				    PRIMARY KEY (`id`)
				  ) $charset_collate;"
				);
			}else{
				$wpdb->query( "ALTER TABLE $inv_operaciones ADD COLUMN IF NOT EXISTS roi int(10) NOT NULL DEFAULT '0'" );	
				$wpdb->query( "ALTER TABLE $inv_operaciones ADD COLUMN IF NOT EXISTS margen int(10) NOT NULL DEFAULT '0'" );
				$wpdb->query( "ALTER TABLE $inv_operaciones ADD COLUMN IF NOT EXISTS roi_user int(10) NOT NULL DEFAULT '0'" );	
				$wpdb->query( "ALTER TABLE $inv_operaciones ADD COLUMN IF NOT EXISTS margen_user int(10) NOT NULL DEFAULT '0'" );
				$wpdb->query( "ALTER TABLE $inv_operaciones ADD COLUMN IF NOT EXISTS inversion DECIMAL(10,2) NOT NULL DEFAULT '0'" );
				$wpdb->query( "ALTER TABLE $inv_operaciones ADD COLUMN IF NOT EXISTS devolucion int(1) NOT NULL DEFAULT '0'" );
			}

			///transacciones
			$inv_transacciones = $wpdb->prefix . "inv_transacciones";
			if($wpdb->get_var("SHOW TABLES LIKE '$inv_transacciones'") != $inv_transacciones) {
				dbDelta(  
				  "CREATE TABLE $inv_transacciones (
				    `id` bigint(20) AUTO_INCREMENT NOT NULL,
				    `user` bigint(20) NOT NULL DEFAULT '1',
				    `cantidad` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `fecha` varchar(255) NOT NULL DEFAULT '',
				    `estado` int(20) NOT NULL DEFAULT '0',
				    PRIMARY KEY (`id`)
				  ) $charset_collate;"
				);
			}

			///deposito
			$inv_depositos = $wpdb->prefix . "inv_depositos";
			if($wpdb->get_var("SHOW TABLES LIKE '$inv_depositos'") != $inv_depositos) {
				dbDelta(  
				  "CREATE TABLE $inv_depositos (
				    `id` bigint(20) AUTO_INCREMENT NOT NULL,
				    `user` bigint(20) NOT NULL DEFAULT '1',
				    `cantidad` DECIMAL(10,2) NOT NULL DEFAULT '0',
				    `fecha` varchar(255) NOT NULL DEFAULT '',
				    PRIMARY KEY (`id`)
				  ) $charset_collate;"
				);
			}

			die("Realizado");
		}

		if(isset($_REQUEST["EJEC_TEST"]) && $_REQUEST["EJEC_TEST"] == 'play' ){

			$despues = strtotime( date("Y-m-d", strtotime("-1 day") ) . " 00:00:00" );
			$antes = strtotime( date("Y-m-d", strtotime("-1 day") ) . " 23:59:59" );

			$operaciones = $this->list_event($despues, $antes);
			
			global $wpdb;
			$inv_productos = $wpdb->prefix . "inv_productos";
			$inv_operaciones = $wpdb->prefix . "inv_operaciones";
			$_products = $wpdb->get_results( "SELECT * FROM $inv_productos $s;", ARRAY_A );
			$productos = [];
			foreach($_products as $pr) $productos[$pr['sku']] = $pr;
			$_data = [];

			///Procesar beneficio
			foreach ($operaciones["op"] as $operacion) {
				if(isset($productos[$operacion["sku"]]) && $_pr = $productos[$operacion["sku"]]){
					$operacion["user"] = $_pr['user'];
					$operacion["compra"] = $operacion["cantidad"] * $_pr['pdc_siva'];
					$operacion["beneficio"] = $_pr['beneficio'];
					$operacion["beneficio_total"] = $operacion["base"] + $operacion["fba"] + $operacion["amz"] - ( $operacion["cantidad"] * ($_pr['pdc_siva'] + $_pr['preparacion'] + $_pr['otros'] + $_pr['transporte']));
					$operacion["beneficio_user"] = number_format((($operacion["beneficio_total"]/100)*$_pr['beneficio']),2);
					$operacion["margen"] = number_format(($operacion["beneficio_total"]/$operacion["base"])* 100,0);
					$operacion["margen_user"] = number_format((($operacion["margen"]/100)*$_pr['beneficio']), 0);
					$operacion["roi"] = number_format(($operacion["beneficio_total"]/$operacion["compra"])* 100,0);
					$operacion["roi_user"] = number_format((($operacion["roi"]/100)*$_pr['beneficio']), 0);
				}else{
					$operacion["beneficio_total"] = $operacion["base"] + $operacion["fba"] + $operacion["amz"];
				}
				$_data[] = $operacion;
			}

			///Procesar devoluciones
			foreach ($operaciones["dv"] as $operacion) {
				$_ant = $wpdb->get_row("SELECT * FROM $inv_operaciones WHERE orden = '$operacion[orden]'", ARRAY_A);
				if($_ant){
					$_ant["compra"] = 0;					
					$_ant["beneficio_total"] = $operacion["amz"] + $_ant["fba"];
					$_ant["beneficio_user"] = number_format((($_ant["beneficio_total"]/100)*$_ant['beneficio']),2);
					$_ant["margen"] = 0;
					$_ant["margen_user"] = 0;
					$_ant["roi"] = 0;
					$_ant["roi_user"] = 0;
					$_ant["devolucion"] = 1;
					$_data[] = $_ant;
				}else{
					echo "<pre>" . print_r($operacion, true) . "</pre>";
				}
			}

			///Mostrar
			echo "<pre>" . print_r($_data, true) . "</pre>";
			echo "<pre>" . print_r($operaciones, true) . "</pre>";
			exit;
		}

		if(isset($_REQUEST["EJEC"]) && $_REQUEST["EJEC"] == 'play' ){
			//$despues = mktime(0, 0, 0, 5, 1, 2021);
			//$antes = mktime(23, 59, 59, 5, 1, 2021);
			$despues = strtotime( date("Y-m-d", strtotime("-1 day") ) . " 00:00:00" );
			$antes = strtotime( date("Y-m-d", strtotime("-1 day") ) . " 23:59:59" );
			$operaciones = $this->list_event($despues, $antes);

			
			global $wpdb;
			$inv_productos = $wpdb->prefix . "inv_productos";
			$inv_operaciones = $wpdb->prefix . "inv_operaciones";
			$_products = $wpdb->get_results( "SELECT * FROM $inv_productos $s;", ARRAY_A );
			$productos = [];
			foreach($_products as $pr) $productos[$pr['sku']] = $pr;
			$_data = [];

			///Procesar beneficio
			foreach ($operaciones["op"] as $operacion) {
				if(isset($productos[$operacion["sku"]]) && $_pr = $productos[$operacion["sku"]]){
					$operacion["user"] = $_pr['user'];
					$operacion["compra"] = $operacion["cantidad"] * $_pr['pdc_siva'];
					$operacion["beneficio"] = $_pr['beneficio'];
					$operacion["beneficio_total"] = $operacion["base"] + $operacion["fba"] + $operacion["amz"] - ( $operacion["cantidad"] * ($_pr['pdc_siva'] + $_pr['preparacion'] + $_pr['otros'] + $_pr['transporte']));
					$operacion["beneficio_user"] = number_format((($operacion["beneficio_total"]/100)*$_pr['beneficio']),2);
					$operacion["margen"] = number_format(($operacion["beneficio_total"]/$operacion["base"])* 100,0);
					$operacion["margen_user"] = number_format((($operacion["margen"]/100)*$_pr['beneficio']), 0);
					$operacion["roi"] = number_format(($operacion["beneficio_total"]/$operacion["compra"])* 100,0);
					$operacion["roi_user"] = number_format((($operacion["roi"]/100)*$_pr['beneficio']), 0);
				}else{
					$operacion["beneficio_total"] = $operacion["base"] + $operacion["fba"] + $operacion["amz"];
				}
				$_data[] = $operacion;
			}

			///Procesar devoluciones
			foreach ($operaciones["dv"] as $operacion) {
				$_ant = $wpdb->get_row("SELECT * FROM $inv_operaciones WHERE orden = '$operacion[orden]'", ARRAY_A);
				if($_ant){
					$_ant["compra"] = 0;					
					$_ant["beneficio_total"] = $operacion["amz"] + $_ant["fba"];
					$_ant["beneficio_user"] = number_format((($_ant["beneficio_total"]/100)*$_ant['beneficio']),2);
					$_ant["margen"] = 0;
					$_ant["margen_user"] = 0;
					$_ant["roi"] = 0;
					$_ant["roi_user"] = 0;
					$_ant["devolucion"] = 1;
					$_data[] = $_ant;
				}else{
					echo "<pre>No se encontro la orden " . print_r($operacion, true) . "</pre>";
					file_put_contents("log.txt", print_r($operacion, true) . "\n", FILE_APPEND);
				}
			}

			///Guardar operaciones
			$_p = 0;
			$_e = 0;
			foreach ($_data as $_new){
				if($wpdb->replace($inv_operaciones, $_new) !== false){
					$_p++;
				}else{
					$_e++;
					echo "<pre>Error al guardar " . print_r($_new, true) . "</pre>";
				}
			}
			echo "Operaciones completadas<br>Exitosos:$_p<br>Errores:$_e";
			exit;
		}

		if(isset($_REQUEST["EJEC_DAY"])){
			if(isset($_REQUEST["EJEC_DAY_2"])){
				$_end = $_REQUEST["EJEC_DAY_2"];
			}else{
				$_end = $_REQUEST["EJEC_DAY"];
			}
			$despues = strtotime( date("Y-m-d", strtotime("-$_end day") ) . " 00:00:00" );
			$antes = strtotime( date("Y-m-d", strtotime("-$_REQUEST[EJEC_DAY] day") ) . " 23:59:59" );
			$operaciones = $this->list_event($despues, $antes);

			
			global $wpdb;
			$inv_productos = $wpdb->prefix . "inv_productos";
			$inv_operaciones = $wpdb->prefix . "inv_operaciones";
			$_products = $wpdb->get_results( "SELECT * FROM $inv_productos $s;", ARRAY_A );
			$productos = [];
			foreach($_products as $pr) $productos[$pr['sku']] = $pr;
			$_data = [];

			///Procesar beneficio
			foreach ($operaciones["op"] as $operacion) {
				if(isset($productos[$operacion["sku"]]) && $_pr = $productos[$operacion["sku"]]){
					$operacion["user"] = $_pr['user'];
					$operacion["compra"] = $operacion["cantidad"] * $_pr['pdc_siva'];
					$operacion["beneficio"] = $_pr['beneficio'];
					$operacion["beneficio_total"] = $operacion["base"] + $operacion["fba"] + $operacion["amz"] - ( $operacion["cantidad"] * ($_pr['pdc_siva'] + $_pr['preparacion'] + $_pr['otros'] + $_pr['transporte']));
					$operacion["beneficio_user"] = number_format((($operacion["beneficio_total"]/100)*$_pr['beneficio']),2);
					$operacion["margen"] = number_format(($operacion["beneficio_total"]/$operacion["base"])* 100,0);
					$operacion["margen_user"] = number_format((($operacion["margen"]/100)*$_pr['beneficio']), 0);
					$operacion["roi"] = number_format(($operacion["beneficio_total"]/$operacion["compra"])* 100,0);
					$operacion["roi_user"] = number_format((($operacion["roi"]/100)*$_pr['beneficio']), 0);
				}else{
					$operacion["beneficio_total"] = $operacion["base"] + $operacion["fba"] + $operacion["amz"];
				}
				$_data[] = $operacion;
			}

			foreach ($operaciones["dv"] as $operacion) {
				$_ant = $wpdb->get_row("SELECT * FROM $inv_operaciones WHERE orden = '$operacion[orden]'", ARRAY_A);
				if($_ant){
					$_ant["compra"] = 0;					
					$_ant["beneficio_total"] = $operacion["amz"] + $_ant["fba"];
					$_ant["beneficio_user"] = number_format((($_ant["beneficio_total"]/100)*$_ant['beneficio']),2);
					$_ant["margen"] = 0;
					$_ant["margen_user"] = 0;
					$_ant["roi"] = 0;
					$_ant["roi_user"] = 0;
					$_ant["devolucion"] = 1;
					$_data[] = $_ant;
				}else{
					echo "<pre>No se encontro la orden " . print_r($operacion, true) . "</pre>";
					file_put_contents("log.txt", print_r($operacion, true) . "\n", FILE_APPEND);
				}
			}

			///Guardar operaciones
			$_p = 0;
			$_e = 0;
			foreach ($_data as $_new){
				if($wpdb->replace($inv_operaciones, $_new) !== false){
					$_p++;
				}else{
					$_e++;
					echo "<pre>Error al guardar " . print_r($_new, true) . "</pre>";
					file_put_contents("log2.txt", print_r($_new, true) . "\n", FILE_APPEND);
				}
			}
			echo "Operaciones completadas<br>Exitosos:$_p<br>Errores:$_e";
			exit;
		}

	}

	echo json_encode($r);
	die();                