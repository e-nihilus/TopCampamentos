<?php

/*
* Plugin Name: SP Admin
* Plugin URI: http://www.santipm.com
* Description: Panel administartivo
* Version: 1.1.0
* Author: Santiago Ponce
* Author URI: http://www.santipm.com
* License:
*/

if ( ! defined( 'ABSPATH' ) ) exit;

define('ADPNSY_VER', '1.1.0');
define('ADPNSY_PATH', realpath( dirname(__FILE__) ) );
define('ADPNSY_URL', plugins_url('/', __FILE__) );

require_once 'admin_license.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';

if ( class_exists('admin_panel_system')){
	class adpnsy extends admin_panel_system {
		public function __construct(){
			add_action( 'admin_menu', array($this, 'menu_register'));
			add_action( 'wp_ajax_admin_panel', array($this, 'ajax'));
			add_action( 'wp_ajax_nopriv_admin_panel', array($this, 'ajax'));
			register_nav_menu( 'admin_system' , __( 'SP menú administrador' , 'adpnsy' ) );
			register_nav_menu( 'perfil_admin_system' , __( 'SP menú perfil usuario' , 'adpnsy' ) );
			add_action( 'init', array($this,'startSession'));
			add_action( 'init', array($this,'custom_role'));
			add_action('show_user_profile', array($this,'custom_user_profile_fields'));
			add_action('edit_user_profile', array($this,'custom_user_profile_fields'));
			add_action( 'personal_options_update', array($this,'update_extra_profile_fields'));
			add_action( 'edit_user_profile_update', array($this,'update_extra_profile_fields'));
			self::init();
		}

		public function menu_register() {
			add_submenu_page('options-general.php', 'SP Admin', 'SP Admin', 'manage_options', 'panel_admin_system', array($this, 'admin'), 20); 
			///extra
			add_menu_page( __('Productos', 'adpnsy'), __('Productos', 'adpnsy'), 'manage_options', 'adpnsy_productos', '', 'dashicons-archive',34);
			add_submenu_page( 'adpnsy_productos', __('Todos los productos', 'adpnsy'), __('Todos los productos', 'adpnsy'), 'manage_options', 'adpnsy_productos', array($this, 'productos'),0);
			add_submenu_page( 'adpnsy_productos', __('Agregar nuevo', 'adpnsy'), __('Agregar producto', 'adpnsy'), 'manage_options', 'adpnsy_producto', array($this, 'producto'),1);
			add_submenu_page( 'adpnsy_productos', __('Importar', 'adpnsy'), __('Importar', 'adpnsy'), 'manage_options', 'adpnsy_producto_import', array($this, 'importar'),2);
			add_menu_page( __('Retiros', 'adpnsy'), __('Retiros', 'adpnsy'), 'manage_options', 'adpnsy_retiros', array($this, 'retiros'), 'dashicons-migrate',34);
			add_menu_page( __('Depositos', 'adpnsy'), __('Depositos', 'adpnsy'), 'manage_options', 'adpnsy_deposito', array($this, 'depositos'), 'dashicons-database-import',34);
			

		}

		public function notificacion_new($n = false){
			$c = 0;

			if($c > 0 && !$n){
				echo '<small class="notification-badge orange accent-3">'.$c.'</small>';
			}			

			if($c > 0 && $n){
				return $c;
			}
		}

		public function notificacion(){
			$n = '';

			if($n != ''){
				echo $n;
			}else{
				echo '<li tabindex="0">Sin notificaciones nuevas</li>';
			}
		}

		public function ajax(){
			include 'admin_ajax.php';
		}

		public function install(){

			//Pages
			$login_ar = array("post_title" => "Login", "post_status" => "publish", "post_type" => "page");
			$login = wp_insert_post($login_ar);
			update_post_meta( $login, '_wp_page_template', 'admin_login.php' );

			$dashboard_ar = array("post_title" => "Dashboard", "post_status" => "publish", "post_type" => "page");
			$dashboard = wp_insert_post($dashboard_ar);
			update_post_meta( $dashboard, '_wp_page_template', 'admin_dashboard.php' );

			$recovery_ar = array("post_title" => "Recuperar Contraseña", "post_status" => "publish", "post_type" => "page");
			$recovery = wp_insert_post($recovery_ar);
			update_post_meta( $recovery, '_wp_page_template', 'admin_recovery.php' );

			$register_ar = array("post_title" => "Registro", "post_status" => "publish", "post_type" => "page");
			$register = wp_insert_post($register_ar);
			update_post_meta( $register, '_wp_page_template', 'admin_register.php' );

			$logout_ar = array("post_title" => "Salir", "post_status" => "publish", "post_type" => "page");
			$logout = wp_insert_post($logout_ar);
			update_post_meta( $logout, '_wp_page_template', 'admin_logout.php' );

			$perfil_ar = array("post_title" => "Perfil", "post_status" => "publish", "post_type" => "page");
			$perfil = wp_insert_post($perfil_ar);
			update_post_meta( $perfil, '_wp_page_template', 'admin_perfil.php' );

			$opciones = json_decode('{
				"titulo":"SP Admin",
				"description":"Instación basica de SP Admin",
				"autor":"Santiago Ponce",
				"logo":"'.ADPNSY_URL.'\/app-assets\/img\/logo_c.png",
				"logo_vn":"0",
				"logo_blanco":"'.ADPNSY_URL.'\/app-assets\/img\/logo_b.png",
				"logo_blanco_vn":"0",
				"logo_texto":"Santiago Ponce",
				"icon_apple":"'.ADPNSY_URL.'\/app-assets\/img\/logo.png",
				"icon_apple_vn":"0",
				"favicon":"'.ADPNSY_URL.'\/app-assets\/img\/logo_c.png",
				"favicon_vn":"0",
				"bglogin_vn":"'.ADPNSY_URL.'\/app-assets\/img\/login.jpg",
				"bglogin":"0",
				"lglogin_vn":"'.ADPNSY_URL.'\/app-assets\/img\/logo.png",
				"lglogin":"0",
				"login":"'.$dashboard.'",
				"Register":"'.$register.'",
				"Recovery":"'.$recovery.'",
				"Politicas":"",
				"botton_fondo":"red",
				"botton_tono":"darken-1",
				"botton_color":"white-text",
				"botton_color_t":"",
				"demo":"1"
			}');

			$menu_Admin_id = wp_create_nav_menu("SP Admin menu");
			$menu_User_id = wp_create_nav_menu("SP Admin menu user");
			wp_update_nav_menu_item($menu_Admin_id, 0, array(
		        'menu-item-title' => 'Dashboard',
			    'menu-item-object-id' => $dashboard,
			    'menu-item-object' => 'page',
			    'menu-item-status' => 'publish',
			    'menu-item-type' => 'post_type',
			));
			wp_update_nav_menu_item($menu_User_id, 0, array(
		        'menu-item-title' => 'Perfil',
			    'menu-item-object-id' => $perfil,
			    'menu-item-object' => 'page',
			    'menu-item-status' => 'publish',
			    'menu-item-type' => 'post_type',
			));
			wp_update_nav_menu_item($menu_User_id, 0, array(
		        'menu-item-title' => 'Salir',
			    'menu-item-object-id' => $logout,
			    'menu-item-object' => 'page',
			    'menu-item-status' => 'publish',
			    'menu-item-type' => 'post_type',
			));

			$locations['admin_system'] = $menu_Admin_id;
			$locations['perfil_admin_system'] = $menu_User_id;        	
        	set_theme_mod( 'nav_menu_locations', $locations );

			return $opciones;
		}

		public function list_event($despues, $antes, $log = false){
			require_once 'mws/index.php';
			return __list_event(date(DATE_FORMAT, $despues), date(DATE_FORMAT, $antes), $log);
		}

		public function startSession() {
		    if(!session_id()) {
		        session_start();
		    }
		}

		public function productos(){
			if(isset($_GET['delete'])){
				global $wpdb;
				$inv_productos = $wpdb->prefix . "inv_productos";
				if($wpdb->delete($inv_productos, ["id" => sanitize_key($_GET['delete'])]) !== false){
					$_SESSION['eliminar_producto'] = true;
				}else{
					$_SESSION['eliminar_producto'] = false;
				}
				echo "<script>location.href='".remove_query_arg('delete')."'</script>";
				exit;
			}

			if(isset($_GET['asignar'])){
				global $wpdb;
				$inv_productos = $wpdb->prefix . "inv_productos";
				$inv_operaciones = $wpdb->prefix . "inv_operaciones";

				$_idp = sanitize_key($_GET['asignar']);

				$_pr = $wpdb->get_row("SELECT * FROM $inv_productos WHERE id='$_idp'", ARRAY_A);
				if($_pr){
					$_operaciones = $wpdb->get_results("SELECT * FROM $inv_operaciones WHERE user='0' AND sku='$_pr[sku]'", ARRAY_A);
					$_p = 0;
					$_e = 0;
					foreach($_operaciones as $_operacion){
						if(!$_operacion["devolucion"]){
							$_operacion["beneficio"] = $_pr["beneficio"];
							$_operacion["user"] = $_pr["user"];
							$_operacion["compra"] = $_operacion["cantidad"] * $_pr['pdc_siva'];
							$_operacion["beneficio_total"] = $_operacion["base"] + $_operacion["fba"] + $_operacion["amz"] - ( $_operacion["cantidad"] * ($_pr['pdc_siva'] + $_pr['preparacion'] + $_pr['otros'] + $_pr['transporte']));
							$_operacion["beneficio_user"] = number_format((($_operacion["beneficio_total"]/100)*$_pr['beneficio']),2);
							$_operacion["margen"] = number_format(($_operacion["beneficio_total"]/$_operacion["base"])* 100,0);
							$_operacion["margen_user"] = number_format((($_operacion["margen"]/100)*$_pr['beneficio']), 0);
							$_operacion["roi"] = number_format(($_operacion["beneficio_total"]/$_operacion["compra"])* 100,0);
							$_operacion["roi_user"] = number_format((($_operacion["roi"]/100)*$_pr['beneficio']), 0);
						}else{
							$_operacion["beneficio"] = $_pr["beneficio"];
							$_operacion["user"] = $_pr["user"];
							$_operacion["beneficio_user"] = number_format((($_operacion["beneficio_total"]/100)*$_pr['beneficio']),2);
						}
						if($wpdb->replace($inv_operaciones, $_operacion) !== false){
							$_p++;
						}else{
							$_e++;
						}
					}
					if($_p > 0 || $_e > 0){
						$_SESSION['asignar_producto'] = 1;
						$_SESSION['asignar_producto_exito'] = $_p;
						$_SESSION['asignar_producto_error'] = $_e;
					}else{
						$_SESSION['asignar_producto'] = 0;
					}
				}else{
					$_SESSION['asignar_producto'] = -1;
				}
				echo "<script>location.href='".remove_query_arg('asignar')."'</script>";
				exit;
			}

			if(isset($_SESSION['eliminar_producto'])){
				if($_SESSION['eliminar_producto'] == true){
					echo "<div class='notice notice-success is-dismissible'><p>Se elimino el producto</p></div>";
				}else{
					echo "<div class='notice notice-error is-dismissible'><p>No se pudo eliminar el producto</p></div>";
				}
				unset($_SESSION['eliminar_producto']);
			}

			if(isset($_SESSION['asignar_producto'])){
				if($_SESSION['asignar_producto'] == 1){
					echo "<div class='notice notice-success is-dismissible'><p>Se Asignaron $_SESSION[asignar_producto_exito] operación(es) al usuario con $_SESSION[asignar_producto_error] error(es)</p></div>";
				}elseif($_SESSION['asignar_producto'] == -1){
					echo "<div class='notice notice-error is-dismissible'><p>No se encontraron el producto</p></div>";
				}else{
					echo "<div class='notice notice-error is-dismissible'><p>No se encontraron operaciones</p></div>";
				}
				unset($_SESSION['asignar_producto']);
				unset($_SESSION['asignar_producto_exito']);
				unset($_SESSION['asignar_producto_error']);
			}

			require_once 'inc/tabla.php';
            $lista = new listar_productos();
            $lista->prepare_items();
            ?>
            	<div class="wrap">
	                <div id="icon-users" class="icon32"></div>
	                <h1 class="wp-heading-inline">Productos</h1>
	                <form action="" method="GET">
	                    <p class="search-box">
	                      <label class="screen-reader-text" for="search-box-id-search-input">Buscar:</label>
	                      <input type="text" id="search-box-id-search-input" name="s" value="<?= isset($_GET['s']) ? $_GET['s'] : ''; ?>">
	                      <input type="submit" id="search-submit" class="button" value="Buscar">
	                    </p>
	                    <input type="hidden" name="page" value="<?=esc_attr($_REQUEST['page']);?>"/>
	                </form>
	                <form id="productos_bulk" method="post">
	                <?php 
	                    $page  = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_STRIPPED );
	                    $paged = filter_input( INPUT_GET, 'paged', FILTER_SANITIZE_NUMBER_INT );
	                    printf( '<input type="hidden" name="page" value="%s" />', $page );
	                    printf( '<input type="hidden" name="paged" value="%d" />', $paged );
	                    $lista->display();
	                  ?>
	                </form>
              </div>
            <?php
		}

		public function producto(){
			include "inc/producto.php";
		}

		public function importar(){
			include "inc/importador.php";
		}

		public function retiros(){

			if(isset($_GET['pagar'])){
				global $wpdb;
				$inv_transacciones = $wpdb->prefix . "inv_transacciones";
				$id = sanitize_key($_GET['pagar']);
				$estado = 1;

				if($wpdb->update($inv_transacciones, ["estado" => $estado], ["id" => $id]) !== false ){
					$_SESSION['exito'] = true;
				}else{
					$_SESSION['error'] = true;
				}
				
				echo "<script>location.href='".remove_query_arg('pagar')."'</script>";
				exit;
			}

			if(isset($_GET['espera'])){
				global $wpdb;
				$inv_transacciones = $wpdb->prefix . "inv_transacciones";
				$id = sanitize_key($_GET['espera']);
				$estado = 0;

				if($wpdb->update($inv_transacciones, ["estado" => $estado], ["id" => $id]) !== false ){
					$_SESSION['exito'] = true;
				}else{
					$_SESSION['error'] = true;
				}
				
				echo "<script>location.href='".remove_query_arg('espera')."'</script>";
				exit;
			}

			if(isset($_GET['cancelar'])){
				global $wpdb;
				$inv_transacciones = $wpdb->prefix . "inv_transacciones";
				$id = sanitize_key($_GET['cancelar']);
				$estado = 2;

				if($wpdb->update($inv_transacciones, ["estado" => $estado], ["id" => $id]) !== false ){
					$_SESSION['exito'] = true;
				}else{
					$_SESSION['error'] = true;
				}
				
				echo "<script>location.href='".remove_query_arg('cancelar')."'</script>";
				exit;
			}


			if(isset($_SESSION['exito'])){
				echo "<div class='notice notice-success is-dismissible'><p>Se cambio el estado</p></div>";
				unset($_SESSION['exito']);
			}

			if(isset($_SESSION['error'])){
				echo "<div class='notice notice-error is-dismissible'><p>Error al cambiar estado</p></div>";
				unset($_SESSION['error']);
			}			

			require_once 'inc/tabla_retiros.php';
            $lista = new listar_productos();
            $lista->prepare_items();
            ?>
            	<div class="wrap">
	                <div id="icon-users" class="icon32"></div>
	                <h1 class="wp-heading-inline">Solicitud de retiro</h1>
	                <form action="" method="GET">
	                    <p class="search-box">
	                      <label class="screen-reader-text" for="search-box-id-search-input">Buscar:</label>
	                      <input type="text" id="search-box-id-search-input" name="s" value="<?= isset($_GET['s']) ? $_GET['s'] : ''; ?>">
	                      <input type="submit" id="search-submit" class="button" value="Buscar">
	                    </p>
	                    <?php if(isset($_GET['st']) && $_GET['st']) echo "<input type='hidden' name='st' value='$_GET[st]' />"; ?>
	                    <?php if(isset($_GET['us']) && $_GET['us']) echo "<input type='hidden' name='us' value='$_GET[us]' />"; ?>
	                    <input type="hidden" name="page" value="<?=esc_attr($_REQUEST['page']);?>"/>
	                </form>
	                <?php 
	                    $page  = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_STRIPPED );
	                    $paged = filter_input( INPUT_GET, 'paged', FILTER_SANITIZE_NUMBER_INT );
	                    printf( '<input type="hidden" name="page" value="%s" />', $page );
	                    printf( '<input type="hidden" name="paged" value="%d" />', $paged );
	                    $lista->display();
	                  ?>
              </div>
            <?php
		}

		public function depositos(){

			if(isset($_GET['delete'])){
				global $wpdb;
				$inv_transacciones = $wpdb->prefix . "inv_transacciones";
				$id = sanitize_key($_GET['delete']);
				$estado = 1;

				if($wpdb->update($inv_transacciones, ["estado" => $estado], ["id" => $id]) !== false ){
					$_SESSION['exito'] = true;
				}else{
					$_SESSION['error'] = true;
				}
				
				echo "<script>location.href='".remove_query_arg('delete')."'</script>";
				exit;
			}


			if(isset($_SESSION['exito'])){
				echo "<div class='notice notice-success is-dismissible'><p>Se elimino el deposito</p></div>";
				unset($_SESSION['exito']);
			}

			if(isset($_SESSION['error'])){
				echo "<div class='notice notice-error is-dismissible'><p>Error al eliminar deposito</p></div>";
				unset($_SESSION['error']);
			}			

			require_once 'inc/tabla_depositos.php';
            $lista = new listar_productos();
            $lista->prepare_items();
            ?>
            	<div class="wrap">
	                <div id="icon-users" class="icon32"></div>
	                <h1 class="wp-heading-inline">Solicitud de depositos</h1>
	                <a href="<?=add_query_arg("new", "true")?>" class="page-title-action">Añadir nuevo</a>
	                <form action="" method="GET">
	                    <p class="search-box">
	                      <label class="screen-reader-text" for="search-box-id-search-input">Buscar:</label>
	                      <input type="text" id="search-box-id-search-input" name="s" value="<?= isset($_GET['s']) ? $_GET['s'] : ''; ?>">
	                      <input type="submit" id="search-submit" class="button" value="Buscar">
	                    </p>
	                    <?php if(isset($_GET['us']) && $_GET['us']) echo "<input type='hidden' name='us' value='$_GET[us]' />"; ?>
	                    <input type="hidden" name="page" value="<?=esc_attr($_REQUEST['page']);?>"/>
	                </form>
	                <?php 
	                    $page  = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_STRIPPED );
	                    $paged = filter_input( INPUT_GET, 'paged', FILTER_SANITIZE_NUMBER_INT );
	                    printf( '<input type="hidden" name="page" value="%s" />', $page );
	                    printf( '<input type="hidden" name="paged" value="%d" />', $paged );
	                    $lista->display();
	                  ?>
              </div>
            <?php
		}

		public function custom_role() {
		    if ( get_option( 'custom_roles_version' ) < 1 ) {
		        add_role( 'inversor_confianza', 'Inversor de Confianza', array( 'read' => true, 'level_0' => true ) );
		        add_role( 'inversor', 'Inversor', array( 'read' => true, 'level_0' => true ) );
		        update_option( 'custom_roles_version', 1 );
		    }
		}

		public function custom_user_profile_fields( $user ) {
		?>
		    <table class="form-table">
		        <tr>
		            <th>
		                <label for="benefico_mm">Beneficio General</label>
		            </th>
		            <td>
		                <input type="number" min="1" step="1" required name="benefico_mm" id="benefico_mm" value="<?php echo esc_attr( get_the_author_meta( 'benefico_mm', $user->ID ) ); ?>" class="regular-text" />
		            </td>
		        </tr>
		    </table>
		<?php
		}
		public function update_extra_profile_fields( $user_id ) {
		    if ( current_user_can( 'edit_user', $user_id ) ) update_user_meta( $user_id, 'benefico_mm', $_POST['benefico_mm'] );
		}

	}
	$GLOBAL['adpnsy'] = new adpnsy();
}
