<?php

if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}


class listar_productos extends WP_List_Table
{

    public function prepare_items(){
      $this->process_bulk_action();
      $columns = $this->get_columns();
      $hidden = $this->get_hidden_columns();
      $sortable = $this->get_sortable_columns();

      $data = $this->table_data();
      if(count($data) > 0)
        usort( $data, array( &$this, 'sort_data' ) );
      $perPage = 20;
      $currentPage = $this->get_pagenum();
      $totalItems = count($data);
      $searchcol = array('nombre');

      if(count($data) > 0)
        $this->set_pagination_args( array(
            'total_items' => $totalItems,
            'per_page'    => $perPage
        ) );
      if(count($data) > 0)
        $data = array_slice($data,(($currentPage-1)*$perPage),$perPage);
      $this->_column_headers = array($columns, $hidden, $sortable);
      $this->items = $data;
    }

    function no_items() {
      _e( 'No hay productos.' );
    }

    public function get_hidden_columns(){
      return array('id');
    }

    public function get_columns(){
      
        $columns = array(
            'cb'              => '<input type="checkbox" />',
            'sku'          => __('SKU', 'adpnsy'),
            'user'           => __('Inversor', 'adpnsy'),
            'beneficio'       => __('Beneficio', 'adpnsy'),
        );
        return $columns;
    }

    public function column_sku($item) {
      $actions['edit'] = sprintf("<a href='%s'>%s</a>'",add_query_arg("page", "adpnsy_producto", add_query_arg( "edit", $item['id'])), __('Editar', 'adpnsy'));
      $actions['asignar'] = sprintf("<a href='%s'>%s</a>'",add_query_arg( "asignar", $item['id']), __('Asignar anteriores', 'adpnsy'));
      $actions['delete'] = sprintf("<a href='%s'>%s</a>'",add_query_arg( "delete", $item['id']), __('Borrar', 'adpnsy'));
      return sprintf('%1$s %2$s', $item['sku'], $this->row_actions($actions) );
    }

    public function column_user($item) {
    	$data_user = get_userdata($item['user']);
    	return $data_user->display_name . "($item[user])";
    }

    public function column_cb($item) {
      return sprintf('<input type="checkbox" name="ids[]" value="%d" />', $item['id']);    
    }

    public function get_sortable_columns(){
      return array(
        'sku' => array('sku', false),
        'user' => array('user', false),
        'beneficio' => array('beneficio', false)
      );
    }

    private function table_data(){
  		$s = "";
  		if(isset($_GET['s'])){
  			$s = $_GET['s'];
  			$s = "WHERE (sku LIKE '%$s%' or data_extra LIKE '%$s%' or user LIKE '%$s%' or id LIKE '%$s%')";
  		}

  		global $wpdb;
  		$inv_productos = $wpdb->prefix . "inv_productos";

  		return $wpdb->get_results( "SELECT id,sku,beneficio,user FROM $inv_productos $s;", ARRAY_A );
    }

    public function column_default( $item, $column_name ){
        switch( $column_name ) {
            case 'id':
            case 'sku':
            case 'beneficio':
            case 'user':
                return $item[ $column_name ];
            default:
                return print_r( $item, true ) ;
        }
    }

    public function get_bulk_actions() {
      return array(
        'delete'      => __( 'Borrar', 'adpnsy' )
      );
    }

    public function process_bulk_action() {

        // security check!
        if ( isset( $_POST['_wpnonce'] ) && ! empty( $_POST['_wpnonce'] ) ) {

            $nonce  = filter_input( INPUT_POST, '_wpnonce', FILTER_SANITIZE_STRING );
            $action = 'bulk-' . $this->_args['plural'];

            if ( ! wp_verify_nonce( $nonce, $action ) )
                wp_die( 'Error de validación' );

        }

        $action = $this->current_action();

        switch ( $action ) {
          case 'delete':
            $this->delete_all($_POST['ids']);
            break;
          default:
            return;
            break;
        }

        return;
    }

    private function delete_all($ids = null){
      /*require_once 'envialia_class_conect.php';
      $envialia = new wc_envialia_conect();
      $borrados = 0;
      $errores = 0;
      foreach ($ids as $id) {
        if($envialia->Borrar_sm($id)){
          $borrados++;
        }else{
          $errores++;
        }
      }
      if(!$errores){
        $envialia->noticia("notice-success is-dismissible",  sprintf(__('Se eliminaron %d orden(es)', 'adpnsy' ), $borrados ));
      }else{
        $envialia->noticia("notice-warning is-dismissible",  sprintf(__('Se eliminaron %d orden(es) con %d error(es)', 'adpnsy' ), $borrados, $errores ));
      }*/
    }

    /**
     * Allows you to sort the data by the variables set in the $_GET
     *
     * @return Mixed
     */
    private function sort_data( $a, $b ){
        // Set defaults
        $orderby = 'id';
        $order = 'desc';
        // If orderby is set, use this as the sort column
        if(!empty($_GET['orderby']))
        {
            $orderby = $_GET['orderby'];
        }
        // If order is set use this as the order
        if(!empty($_GET['order']))
        {
            $order = $_GET['order'];
        }
        $result = strnatcmp( $a[$orderby], $b[$orderby] );
        if($order === 'asc')
        {
            return $result;
        }
        return -$result;
    }

}


