jQuery(document).ready( function($) {
	$(".login-form").on("submit", function(e){
		$(".exito-login").slideUp();
		if($("#username").val() == "" && $("#password").val() == ""){
			e.preventDefault();
			$(".error-login").html("Por favor ingrese su usuario y contraseña").slideDown().delay(2000).slideUp();
			return false;
		}
		if($("#username").val() == ""){
			e.preventDefault();
			$(".error-login").html("Por favor ingrese un usuario valido").slideDown().delay(2000).slideUp();
			return false;
		}
		if($("#password").val() == ""){
			e.preventDefault();
			$(".error-login").html("Por favor ingrese su contraseña").slideDown().delay(2000).slideUp();
			return false;
		}
	})

	$(".recovery-form").on("submit", function(e){
		$(".exito-login").slideUp();
		if($("#password-2").val() == "" && $("#password").val() == ""){
			e.preventDefault();
			$(".error-login").html("Por favor rellene todo los campos").slideDown().delay(2000).slideUp();
			return false;
		}
		if($("#password").val() != $("#password-2").val()){
			e.preventDefault();
			$(".error-login").html("Contraseñas no coinciden").slideDown().delay(2000).slideUp();
			return false;
		}
	})

	$("#user_select").change(function(e){
		if($("#oper_dates").length ){
			if($("#_user").length && $(this).val()){
				$("#_user").val($(this).val());
			}else if($("#_user").length && !$(this).val()){
				$("#_user").remove();
			}else if(!$("#_user").length && $(this).val()){
				$("#oper_dates").prepend("<input type='hidden' name='u' value='"+$(this).val()+"' />");
			}
			$("#oper_dates").submit()
		}else if($(this).val()){
			window.location.href = window.location.origin + window.location.pathname + "?u=" + $(this).val();
		}else{
			window.location.href = window.location.origin + window.location.pathname;
		}
		
	})

	$(".change_user").click(function(e){
		$(".modal-user").fadeIn();
	})

	$(".modal-user-cont span").click(function(e){
		$(".modal-user").fadeOut();
	})

	$(".register-form").on("submit", function(e){
		$(".exito-login").slideUp();
		if($("#password2").val() == "" || $("#password").val() == "" || $("#username").val() == ""){
			e.preventDefault();
			$(".error-login").html("Por favor rellene todo los campos").slideDown().delay(2000).slideUp();
			return false;
		}

		if($("#username").val() == "" || $("#username").val().length < 6){
			e.preventDefault();
			$(".error-login").html("Por favor ingrese un usuario valido de al menos 6 caracteres").slideDown().delay(2000).slideUp();
			return false;
		}
		if($("#password").val() == "" || $("#password").val().length < 6){
			e.preventDefault();
			$(".error-login").html("Por favor ingrese una contraseña valida de al menos 6 caracteres").slideDown().delay(2000).slideUp();
			return false;
		}

		if($("#password").val() != $("#password2").val()){
			e.preventDefault();
			$(".error-login").html("Contraseñas no coinciden").slideDown().delay(2000).slideUp();
			return false;
		}

		if(!$("#aceptar").prop("checked")){
			e.preventDefault();
			$(".error-login").html("Debe leer y aceptar nuestra políticas de privacidad").slideDown().delay(2000).slideUp();
			return false;
		}
	})

	$(".error-login, .exito-login").click(function(e){
		$(this).slideUp();
	});

	$(".date-input").datepicker({
		autoClose: true,
		format: "dd-mm-yyyy",
		setDefaultDate: true,
		maxDate: new Date()
	});

	$(".datatable").DataTable({
		"pageLength": 10,
		"order": [[ 0, "desc" ]],
      	"language": {
			"lengthMenu" : "Mostrando _MENU_ registros por página",
			"zeroRecords": "No hay registros por mostrar",
			"info"       : "Mostrando _PAGE_ de _PAGES_",
			"infoEmpty"  : "Sin registros en este momento",
			"search"     : "Buscar",
			"paginate": {
				"first":      "Primera",
				"last":       "Ultima",
				"next":       "Siguiente",
				"previous":   "Anterior"
			}
		}
    });

    $("#retirar").submit(function(e){
    	e.preventDefault();
    	var cant = $("#retirar_cant").val();
    	$("#retirar_btn").prop( "disabled", true );
    	$("#retirar_cant").prop( "disabled", true );
    	$.ajax({
		  type: "POST",
		  url: "#",
		  data: {
		  	Xsolc: cant
		  },
		  error: function(data){
		  	$("#retirar_btn").prop( "disabled", false );
    		$("#retirar_cant").prop( "disabled", false );
    		swal({title: "No completado intente mas tarde", icon: "error"});
		  },
		  success: function(data){
		  	window.location.reload();
		  }
		});
    })

	if($(".charts-blanc").length) Chart.defaults.global.defaultFontColor='#fff';

	$(".charts").each(function(k,v){
		var labels = JSON.parse($(v).attr("data-labels"));
		var datos = JSON.parse($(v).attr("data-datos"));
		var fondo = $(v).attr("data-fondo");
		var line = $(v).attr("data-line");
		var type = $(v).attr("data-type");
		var label = $(v).attr("data-label");
		var currency = $(v).attr("data-currency");
		var ctx = $(v)[0].getContext('2d');
		var myChart = new Chart(ctx, {
		    type: type,
		    data: {
		        labels: labels,
		        datasets: [{
		            label: label,
		            data: datos,
		            backgroundColor: fondo,
		            borderColor: line,
		            borderWidth: 1
		        }]
		    },
		    options: {
		        scales: {
		            y: {
		                beginAtZero: true
		            },
		            yAxes: [{
			        	ticks: {
			           		callback: function(value, index, values) {
			           			if(currency == 1) return value.toLocaleString("es-ES",{style:"currency", currency:"EUR"});
			           			return value;
			            	}
			         	}
			       	}]
		        }
		    }
		});
	})

});