<?php
  $success = 0;
  if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $iban = $_POST["iban_user"];
    $banco = $_POST["banco_user"];
    if(!isset($iban) || !isset($banco)){
      echo '<script type="text/javascript">
        swal({
          title: "Por favor complete todos los datos",
          timer: 2000,
          icon: "error"
        });
      </script>';
    }else{
        update_user_meta( get_current_user_id(), "iban_user", $iban );
        update_user_meta( get_current_user_id(), "banco_user", $banco );
        echo '<script type="text/javascript">
          swal({
            title: "Datos actualizados correctamente",
            timer: 2000,
            icon: "success"
          });
        </script>';
    }
  }

?>
<div class="breadcrumbs" id="breadcrumbs-wrapper">
    <div class="container">
        <div class="row">
        <div class="col s12">
            <div class="nav-wrapper">
                <div class="col s12">
                    <a href="/dashboard" class="breadcrumb">Panel de administración</a>
                    <a href="#" class="breadcrumb">Datos Bancarios</a>
                </div>
            </div>
        </div>
        <div class="col s10 m6 l6">
            <h5 class="breadcrumbs-title mt-0 mb-0">Datos Bancarios</h5>                
        </div>              
        </div>
    </div>
</div>
<div class="container">
    <div class="row">   
        <div class="col s12">
        <div class="container">
            <div class="section" id="user-profile">
            <div class="row">
                <div class="col s12">
                <div class="row">
                    <div class="card user-card2" id="feed">
                    <div class="card-content card-border-gray" >
                        <div class='error-form'></div>
                        <form class="perfil-fact-form" method="post" action="#" autocomplete="off">
                        <table style="width: 100%">
                            <tbody>
                                <tr>
                                    <td>
                                    <p class="form-row form-row-first validate-required" id="amazon_store">
                                    <label for="banco_user" class="">Nombre del Banco&nbsp;<abbr class="required" title="obligatorio">*</abbr></label>
                                    <span class="woocommerce-input-wrapper">
                                        <input type="text" class="input-text" name="banco_user" id="banco_user" placeholder="" value="<?= get_user_meta( get_current_user_id(), 'banco_user' )[0] ?>" autocomplete="off">
                                    </span>
                                    </p> 
                                </td>
                                </tr>
                                <tr>
                                <td>
                                    <p class="form-row form-row-first validate-required" id="amazon_store">
                                    <label for="iban_user" class="">IBAN&nbsp;<abbr class="required" title="obligatorio">*</abbr></label>
                                    <span class="woocommerce-input-wrapper">
                                        <input type="text" class="input-text" name="iban_user" id="iban_user" placeholder="" value="<?= get_user_meta( get_current_user_id(), 'iban_user' )[0] ?>" autocomplete="off">
                                    </span>
                                    </p> 
                                </td>
                                </tr>
                                <tr>
                                    <td>
                                        <button type="submit" id="panel_user_confirm" class="btn waves-effect waves-light <?=$info->botton_color?> <?=$info->botton_color_t?> <?=$info->botton_fondo?> <?=$info->botton_tono?> col s12">Guardar datos</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        </form>
                    </div>
                    </div>
                </div>
                </div>    
            </div>
            </div>
        </div>
        </div>
    </div>
</div>