<?php 

	global $wpdb;

	$_user = wp_get_current_user();
	if ( in_array( 'administrator', (array) $_user->roles ) ) {
	   	if(isset($_GET['u'])){
	   		$_u = $_GET['u'];
			$user = "user='$_u'";
	   	}else{
	   		$user = "1=1";
	   		$_u = 0;
		}
	}else{
		$_u = get_current_user_id();
		$user = "user='$_u'";
	}

	$inv_productos = $wpdb->prefix . "inv_productos";
	$inv_operaciones = $wpdb->prefix . "inv_operaciones";
	$inv_transacciones = $wpdb->prefix . "inv_transacciones";

	///Operaciones
	$_total_oper = $wpdb->get_var("SELECT count(*) FROM $inv_operaciones WHERE $user;");
	$_last_oper  = $wpdb->get_var("SELECT count(*) FROM $inv_operaciones WHERE $user AND fecha >= '" . date("Y-m-d", strtotime("-1 day")) . "'");

	///Productos
	$_total_prod = $wpdb->get_var("SELECT count(*) FROM $inv_productos WHERE $user;");
	$_promedio_b = round(($wpdb->get_var("SELECT SUM(beneficio) FROM $inv_productos WHERE $user;") / $_total_prod), 2);

	///Ventas
	$_total_vent = sprintf('%.2f', $wpdb->get_var("SELECT SUM(beneficio_user) FROM $inv_operaciones WHERE $user;"));
	$_last_vents = sprintf('%.2f', $wpdb->get_var("SELECT SUM(beneficio_user) FROM $inv_operaciones WHERE $user AND fecha >= '" . date("Y-m-d", strtotime("-1 day")) . "'"));

	///Monedero
	$_total_debt = sprintf('%.2f', $wpdb->get_var("SELECT SUM(cantidad) FROM $inv_transacciones WHERE $user AND estado='1';"));
	$_total_disp = sprintf('%.2f', $_total_vent - $_total_debt);

	///Gráficas
	$_dias = []; 
	$_last7_oper = []; 
	$_last7_vent = []; 

	for ($i=-7; $i < 0; $i++) { 
		$_qr = "SELECT count(*) FROM `$inv_operaciones` WHERE $user AND `fecha` BETWEEN '".date("Y-m-d", strtotime("$i day"))." 00:00:00' AND '".date("Y-m-d", strtotime("$i day"))."  23:59:59'";
		$_qr2 = "SELECT SUM(beneficio_user) FROM `$inv_operaciones` WHERE $user AND `fecha` BETWEEN '".date("Y-m-d", strtotime("$i day"))." 00:00:00' AND '".date("Y-m-d", strtotime("$i day"))."  23:59:59'";
		$_last7_oper[] = $wpdb->get_var($_qr);
		$_last7_vent[] = sprintf('%.2f', $wpdb->get_var($_qr2));
		$_dias[] = date("d/m/Y", strtotime("$i day"));
	}

?>

<?php if ( in_array( 'administrator', (array) $_user->roles ) && isset($_GET['u'])){ ?>
	<div class="breadcrumbs" id="breadcrumbs-wrapper">
	  <div class="container">
	    <div class="row">
	      <div class="col s12">
	        <div class="nav-wrapper">
	            <div class="col s12">
	                <a href="<?=get_permalink();?>" class="breadcrumb">Dashboard</a>
	                <?='<a href="#" class="breadcrumb">' . get_userdata($_GET['u'])->data->display_name . "</a>";?>
	            </div>
	        </div>
	      </div>
	      <div class="col s10 m6 l6">
	        <h5 class="breadcrumbs-title mt-0 mb-0">
	          Dashboard
	            <?=' de ' . get_userdata($_GET['u'])->data->display_name;?>
	        </h5>                
	      </div>              
	    </div>
	  </div>
	</div>
<?php } ?>

<div id="card-stats" class="pt-0">
	<div class="row">
	    <div class="col s12 m6 l6 xl3">
	        <div class="card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text animate fadeLeft">
	            <div class="padding-4">
	                <div class="row">
	                    <div class="col s7 m7">
	                        <i class="material-icons background-round mt-5">add_shopping_cart</i>
	                        <p>Productos vendidos</p>
	                    </div>
	                    <div class="col s5 m5 right-align">
	                        <h5 class="mb-0 white-text"><?=$_last_oper;?></h5>
	                        <p class="no-margin">Nuevas</p>
	                        <p><?=$_total_oper;?></p>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	    <div class="col s12 m6 l6 xl3">
	        <div class="card gradient-45deg-red-pink gradient-shadow min-height-100 white-text animate fadeLeft">
	            <div class="padding-4">
	                <div class="row">
	                    <div class="col s7 m7">
	                        <i class="material-icons background-round mt-5">inventory_2</i>
	                        <p>Productos</p>
	                    </div>
	                    <div class="col s5 m5 right-align">
	                        <h5 class="mb-0 white-text"><?=$_promedio_b;?>%</h5>
	                        <p class="no-margin">Ganacia promedio</p>
	                        <p><?=$_total_prod;?></p>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	    <div class="col s12 m6 l6 xl3">
	        <div class="card gradient-45deg-amber-amber gradient-shadow min-height-100 white-text animate fadeRight">
	            <div class="padding-4">
	                <div class="row">
	                    <div class="col s7 m7">
	                        <i class="material-icons background-round mt-5">timeline</i>
	                        <p>Ventas</p>
	                    </div>
	                    <div class="col s5 m5 right-align">
	                        <h5 class="mb-0 white-text"><?=$_last_vents;?> €</h5>
	                        <p class="no-margin">ultimas 24horas</p>
	                        <p><?=$_total_vent;?> €</p>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	    <div class="col s12 m6 l6 xl3">
	        <div class="card gradient-45deg-green-teal gradient-shadow min-height-100 white-text animate fadeRight">
	            <div class="padding-4">
	                <div class="row">
	                    <div class="col s7 m7">
	                        <i class="material-icons background-round mt-5">attach_money</i>
	                        <p>Monedero</p>
	                    </div>
	                    <div class="col s5 m5 right-align">
	                        <h5 class="mb-0 white-text"><?= $_total_disp ?>€</h5>
	                        <p class="no-margin">disponible</p>
	                        <p>Procesando: <?= $_total_debt ?>€</p>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
</div>
<div id="chart-dash">
    <div class="row">
        <div class="col s12 m6 l6">
            <div id="revenue-chart" class="card animate fadeUp">
                <div class="card-content">
                	<h4 class="header mt-0">
                        Últimos 7 días de ordenes
                    </h4>
                    <div class="row">
                        <div class="col s12">
                            <canvas class="charts" data-fondo='rgba(2, 136, 209, 0.7)' data-currency="0" data-type='line' data-line="rgba(2, 136, 209, 1)" data-labels='<?=json_encode($_dias);?>' data-datos='<?=json_encode($_last7_oper);?>' data-label='# operaciones' height="100"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col s12 m6 l6">
            <div id="revenue-chart" class="card animate fadeUp">
                <div class="card-content">
                	<h4 class="header mt-0">
                        Últimos 7 días de Ganancias
                    </h4>
                    <div class="row">
                        <div class="col s12">
                            <canvas class="charts" data-fondo='rgba(255, 111, 0, 0.7)' data-currency='1' data-type='line' data-line="rgba(255, 111, 0, 1)" data-labels='<?=json_encode($_dias);?>' data-datos='<?=json_encode($_last7_vent);?>' data-label='# ganacias' height="100"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ( in_array( 'administrator', (array) $_user->roles ) ):  ?>
	<div class="fixed-action-btn change_user"><a class="btn-floating btn-large gradient-shadow"><i class="material-icons">filter_list</i></a></div>
	<div class="modal-user">
		<div class="modal-user-cont">
			<span>X</span>
			<h4>Seleccione un usuario</h4>
			<?php $users = get_users( array( 'fields' => array( 'ID', 'display_name' ) ) ); ?>
			<select id='user_select'>
				<option value="">Todas las operaciones</option>
				<?php foreach($users as $user){
					if($_u == $user->ID){
						echo "<option selected value='$user->ID'>$user->display_name</option>";
					}else{
						echo "<option value='$user->ID'>$user->display_name</option>";
					}
				} ?>
			</select>
		</div>
	</div>
<?php endif; ?>

