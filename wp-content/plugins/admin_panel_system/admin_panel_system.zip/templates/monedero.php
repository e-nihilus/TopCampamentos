<?php
  global $wpdb;

  $_user = wp_get_current_user();
  if ( in_array( 'administrator', (array) $_user->roles ) ) {
      if(isset($_GET['u'])){
        $_u = $_GET['u'];
      $user = "user='$_u'";
      }else{
        $user = "1=1";
        $_u = 0;
    }
  }else{
    $_u = get_current_user_id();
    $user = "user='$_u'";
  }

  $inv_transacciones = $wpdb->prefix . "inv_transacciones";
  $inv_operaciones = $wpdb->prefix . "inv_operaciones";
  $inv_depositos = $wpdb->prefix . "inv_depositos";


  //Grabado
  if(isset($_POST['Xsolc'])){
    $_cant = $_POST['Xsolc'];
    $_new = [ "user" => $_u, "cantidad" => $_cant, "fecha" => date("d/m/Y H:i:s"), "estado" => 0 ];
    if($wpdb->insert($inv_transacciones, $_new) !== false){
      echo "<script>swal({title: 'Solicitud realizada', icon: 'success'})</script>";
    }else{
      echo "<script>swal({title: 'Solicitud no se pud realizar intente mas tarde', icon: 'error'})</script>";
    }
  }

  //Datos
  $_total_retiro = sprintf('%.2f', $wpdb->get_var("SELECT SUM(cantidad) FROM $inv_transacciones WHERE $user AND estado='1';"));
  $_operaciones = $wpdb->get_results("SELECT fecha, estado, cantidad FROM $inv_transacciones WHERE $user;");
  //$_inversion_total = sprintf('%.2f', $wpdb->get_var("SELECT SUM(cantidad) FROM $inv_depositos WHERE $user;"));
  //$_inversiones = $wpdb->get_results("SELECT fecha, cantidad FROM $inv_depositos WHERE $user;");
  $date = strtotime("-61 day");


  $_inversion_recuperada = sprintf('%.2f', $wpdb->get_var("SELECT SUM(compra) FROM $inv_operaciones WHERE $user AND fecha < '".date("Y-m-d", $date)." 00:00:00';"));
  $_inversion_total = sprintf('%.2f', $wpdb->get_var("SELECT SUM(compra) FROM $inv_operaciones WHERE $user;"));

  if($_u){
    $_roi = $wpdb->get_var("SELECT AVG(roi_user) FROM $inv_operaciones WHERE $user AND roi_user > 0;");
    $_margen = $wpdb->get_var("SELECT AVG(margen_user) FROM $inv_operaciones WHERE $user AND margen_user > 0;");
    $_beneficio = sprintf('%.2f', $wpdb->get_var("SELECT SUM(beneficio_user) FROM $inv_operaciones WHERE $user AND fecha < '".date("Y-m-d", $date)." 00:00:00';"));
    $_procesando = sprintf('%.2f', $wpdb->get_var("SELECT SUM(beneficio_user) FROM $inv_operaciones WHERE $user AND fecha > '".date("Y-m-d", $date)." 00:00:00';"));

  }else{
    $_roi = $wpdb->get_var("SELECT AVG(roi) FROM $inv_operaciones WHERE $user AND roi > 0;");
    $_margen = $wpdb->get_var("SELECT AVG(margen) FROM $inv_operaciones WHERE $user AND margen > 0;");
    $_beneficio = sprintf('%.2f', $wpdb->get_var("SELECT SUM(beneficio_total) FROM $inv_operaciones WHERE $user AND fecha < '".date("Y-m-d", $date)." 00:00:00';"));
    $_procesando = sprintf('%.2f', $wpdb->get_var("SELECT SUM(beneficio_total) FROM $inv_operaciones WHERE $user AND fecha > '".date("Y-m-d", $date)." 00:00:00';"));
  }



  //misc
  $_st = [0 => "<span class='cyan-text'>En espera</span>", 1 => "<span class='text-green'>Pagado</span>", 2 => "<span class='orange-text text-accent-4'>Cancelado</span>", 3 => "<span class='teal-text'>Inversión</span>" ];

?>

<div class="breadcrumbs" id="breadcrumbs-wrapper">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <div class="nav-wrapper">
            <div class="col s12">
                <a href="/dashboard" class="breadcrumb">Dashboard</a>
                <a href="<?=get_permalink();?>" class="breadcrumb">Monedero</a>
                <?php if ( in_array( 'administrator', (array) $_user->roles ) && isset($_GET['u'])){
                  echo '<a href="#" class="breadcrumb">' . get_userdata($_GET['u'])->data->display_name . "</a>";
                } ?>
            </div>
        </div>
      </div>
      <div class="col s10 m6 l6">
        <h5 class="breadcrumbs-title mt-0 mb-0">
          Monedero
            <?php if ( in_array( 'administrator', (array) $_user->roles ) && isset($_GET['u'])){
              echo ' de ' . get_userdata($_GET['u'])->data->display_name;
            } ?>
        </h5>                
      </div>              
    </div>
  </div>
</div>
<div class="container monedero">
  <div class="row">
    <div class="col s12">
      <div class="container">
        <div class="section">
          <div class="row">
            <!-- Disponible -->
            <div class="col s12 m6 xl">
              <div class="card animate fadeLeft">
                <div class="card-content green white-text">
                  <p class="card-stats-title">Dinero disponible</p>
                  <h4 class="card-stats-number white-text"><?=sprintf('%.2f', ($_inversion_recuperada+$_beneficio-$_total_retiro));?> €</h4>
                </div>
              </div>
            </div>

            <!-- Invertido -->
            <div class="col s12 m6 xl">
              <div class="card animate fadeLeft">
                <div class="card-content cyan white-text">
                  <p class="card-stats-title">Inversion recuperada</p>
                  <h4 class="card-stats-number white-text"><?=$_inversion_recuperada;?> €</h4>
                </div>
              </div>
            </div>
            
            <!-- ROI/MARGEN -->
            <div class="col s12 m6 xl">
              <div class="card animate fadeLeft">
                <div class="card-content orange accent-4 white-text">
                  <p class="card-stats-title">ROI / Margen</p>
                  <h4 class="card-stats-number white-text"><?=number_format($_roi, 0);?>% / <?=number_format($_margen,0);?>%</h4>
                </div>
              </div>
            </div>

            <!-- Beneficio -->
            <div class="col s12 m6 xl">
              <div class="card animate fadeLeft">
                <div class="card-content teal white-text">
                  <p class="card-stats-title">Beneficio</p>
                  <h4 class="card-stats-number white-text"><?=$_beneficio;?> €</h4>
                </div>
              </div>
            </div>

            <!-- Procesando -->
            <div class="col s12 m6 xl">
              <div class="card animate fadeLeft">
                <div class="card-content yellow darken-3 white-text">
                  <p class="card-stats-title">Procesando</p>
                  <h4 class="card-stats-number white-text"><?=$_procesando;?> €</h4>
                </div>
              </div>
            </div>

            <?php if ( !in_array( 'administrator', (array) $_user->roles ) ):  ?>
              <div class="col s12">
                <div class="card">
                  <div class="card-content card-border-gray" >
                    <form class="row" method="post" id="retirar">
                      <div class="input-field col s9 m-0">
                        <i class="material-icons prefix">assignment_returned</i>
                        <input required id="retirar_cant" type="number" step="0.01" min="1" max="<?=$_total_disponible;?>" class="validate">
                        <label for="retirar_cant">Cantidad a Retirar</label>
                      </div>
                      <button id="retirar_btn" class="col s3 btn waves-effect waves-light green" type="submit" name="action">Solicitar Retiro <i class="material-icons right">send</i></button>
                    </form>
                  </div>
                </div>
              </div>
            <?php endif; ?>


            <div class="col s12">
              <div class="card">
                <div class="card-content card-border-gray" >
                  
                  <table class="datatable">
                    <thead>
                      <tr>
                        <th>Fecha</th>
                        <th>Estado</th>
                        <th>Cantidad</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($_operaciones as $_operacion){ ?>
                        <tr>
                          <td data-sort="<?=strtotime(str_replace("/", "-", $_operacion->fecha));?>"><?=$_operacion->fecha;?></td>
                          <td><?=$_st[$_operacion->estado];?></td>
                          <td><?=sprintf('%.2f', $_operacion->cantidad);?> €</td>
                        </tr>
                      <?php } ?>
                      <?php /* foreach($_inversiones as $_inversion){ ?>
                        <tr>
                          <td data-sort="<?=strtotime(str_replace("/", "-", $_inversion->fecha));?>"><?=$_inversion->fecha;?></td>
                          <td><?=$_st[3];?></td>
                          <td><?=sprintf('%.2f', $_inversion->cantidad);?> €</td>
                        </tr>
                      <?php } */ ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <!-- Inversion total -->
            <div class="col s12 m6 xl3">
              <div class="card animate fadeLeft">
                <div class="card-content green white-text">
                  <p class="card-stats-title">Inversion total</p>
                  <h4 class="card-stats-number white-text"><?=$_inversion_total;?> €</h4>
                </div>
              </div>
            </div>

            <!-- Roi -->
            <div class="col s12 m6 xl3">
              <div class="card animate fadeLeft">
                <div class="card-content cyan white-text">
                  <p class="card-stats-title">ROI</p>
                  <h4 class="card-stats-number white-text"><?=number_format( (($_procesando + $_beneficio) / $_inversion_total)*100,0);?>%</h4>
                </div>
              </div>
            </div>
            
            <!-- ROI/MARGEN -->
            <div class="col s12 m6 xl3">
              <div class="card animate fadeLeft">
                <div class="card-content orange accent-4 white-text">
                  <p class="card-stats-title">Total retirado</p>
                  <h4 class="card-stats-number white-text"><?=$_total_retiro;?> €</h4>
                </div>
              </div>
            </div>

            <!-- Procesando -->
            <div class="col s12 m6 xl3">
              <div class="card animate fadeLeft">
                <div class="card-content yellow darken-3 white-text">
                  <p class="card-stats-title">Beneficio total</p>
                  <h4 class="card-stats-number white-text"><?=sprintf('%.2f', ($_procesando + $_beneficio));?> €</h4>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php if ( in_array( 'administrator', (array) $_user->roles ) ):  ?>
  <div class="fixed-action-btn change_user"><a class="btn-floating btn-large gradient-shadow"><i class="material-icons">filter_list</i></a></div>
  <div class="modal-user">
    <div class="modal-user-cont">
      <span>X</span>
      <h4>Seleccione un usuario</h4>
      <?php $users = get_users( array( 'fields' => array( 'ID', 'display_name' ) ) ); ?>
      <select id='user_select'>
        <option value="">Todas las operaciones</option>
        <?php foreach($users as $user){
          if($_u == $user->ID){
            echo "<option selected value='$user->ID'>$user->display_name</option>";
          }else{
            echo "<option value='$user->ID'>$user->display_name</option>";
          }
        } ?>
      </select>
    </div>
  </div>
<?php endif; ?>

