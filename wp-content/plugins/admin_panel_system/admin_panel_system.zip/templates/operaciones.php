<?php
	$_date_d = strtotime("-33 day");
	$_date_h = strtotime("-2 day");
	if(isset($_GET['d']) && $_GET['d'] && isset($_GET['h']) && $_GET['h']){
		$_date_d = strtotime($_GET['d']);
		$_date_h =strtotime($_GET['h']);
	}

	$_dates = [];
	$_opers = [];
	$_profi = [];
	$_opers_all = [];
	$_con = false;

	global $wpdb;

  $_user = wp_get_current_user();
  if ( in_array( 'administrator', (array) $_user->roles ) ) {
  	$_con = true;
    if(isset($_GET['u'])){
      $_u = $_GET['u'];
    	$user = "user='$_u'";
    }else{
      $user = "1=1";
      $_u = 0;
  	}
  }else{
  	if ( in_array( 'inversor_confianza', (array) $_user->roles ) ) $_con = true;
    $_u = get_current_user_id();
    $user = "user='$_u'";
  }

	$inv_productos = $wpdb->prefix . "inv_productos";
	$inv_operaciones = $wpdb->prefix . "inv_operaciones";

	if($_date_h - $_date_d > 86400 * 31 ){
		$_date_h = $_date_d + (86400 * 31);
		echo "<script>swal({title: 'Rango máximo permitido 31 Días', icon: 'warning'})</script>";
	}

	if($_date_h < $_date_d){
		echo "<script>swal({title: 'El rango mínimo debe ser menos al rango máximo', icon: 'error'})</script>";
	}

	
	$current = $_date_d;

	for ( $i = 0; $i < 32; $i++ ) {
		$_dates[] = date( 'd/m/Y', $current );
		$_opers[] = $wpdb->get_var("SELECT count(*) FROM `$inv_operaciones` WHERE $user AND roi > 0 AND `fecha` BETWEEN '".date("Y-m-d", $current)." 00:00:00' AND '".date("Y-m-d", $current)."  23:59:59'");
		
		//news
		if(!$_u){
			$_profi[] = sprintf('%.2f', $wpdb->get_var("SELECT SUM(beneficio_total) FROM `$inv_operaciones` WHERE $user AND roi > 0 AND `fecha` BETWEEN '".date("Y-m-d", $current)." 00:00:00' AND '".date("Y-m-d", $current)."  23:59:59'"));
		}else{
			$_profi[] = sprintf('%.2f', $wpdb->get_var("SELECT SUM(beneficio_user) FROM `$inv_operaciones` WHERE $user AND roi > 0 AND `fecha` BETWEEN '".date("Y-m-d", $current)." 00:00:00' AND '".date("Y-m-d", $current)."  23:59:59'"));
		}
		

		if($current >= $_date_h){
			$i = 32;
		}else{
			$current += 86400;
		}
	}

	if(!$_u){
		$_opers_all = $wpdb->get_results("SELECT cantidad as ventas, beneficio_total as beneficio, margen as margen, roi as roi, sku, fecha, orden FROM `$inv_operaciones` WHERE $user AND `fecha` BETWEEN '".date("Y-m-d", $_date_d)." 00:00:00' AND '".date("Y-m-d", $_date_h)."  23:59:59'");
	}else{
		$_opers_all = $wpdb->get_results("SELECT cantidad as ventas, beneficio_user as beneficio, margen_user as margen, roi_user as roi, sku, fecha, orden FROM `$inv_operaciones` WHERE $user AND roi > 0 AND `fecha` BETWEEN '".date("Y-m-d", $_date_d)." 00:00:00' AND '".date("Y-m-d", $_date_h)."  23:59:59'");
	}

	$_date_d = date("m-d-Y", $_date_d);
	$_date_h = date("m-d-Y", $_date_h);

?>
<div class="breadcrumbs" id="breadcrumbs-wrapper">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <div class="nav-wrapper">
            <div class="col s12">
                <a href="/dashboard" class="breadcrumb">Dashboard</a>
                <a href="<?=get_permalink();?>" class="breadcrumb">Operaciones</a>
                <?php if ( in_array( 'administrator', (array) $_user->roles ) && isset($_GET['u'])){
                	echo '<a href="#" class="breadcrumb">' . get_userdata($_GET['u'])->data->display_name . "</a>";
      					} ?>
            </div>
        </div>
      </div>
      <div class="col s10 m6 l6">
        <h5 class="breadcrumbs-title mt-0 mb-0">
        	Operaciones
        		<?php if ( in_array( 'administrator', (array) $_user->roles ) && isset($_GET['u'])){
            	echo ' de ' . get_userdata($_GET['u'])->data->display_name;
  					} ?>
        </h5>                
      </div>              
    </div>
  </div>
</div>
<div class="container charts-blanc">
  	<div class="row">   
	    <div class="col s12">
	      	<div class="container">
		        <div class="section">
		          	<div class="row">
		          		<div class="col s12">
	                	<div class="card">
                  		<div class="card-content card-border-gray" >
                  			<form method="GET" class="row" id="oper_dates">
                  				<?php  if ( in_array( 'administrator', (array) $_user->roles ) && isset($_GET['u'])) {
											        echo "<input id='_user' type='hidden' name='u' value='$_u' />";
											     } ?>
	                  			<div class="col s6 m4">
                              <div class="input-field">
                                  <input class="date-input" type="text" name="d" value="<?=$_date_d;?>" >
                                  <label for="cr-date">Desde</label>
                              </div>
                          </div>
                          <div class="col s6 m4">
                              <div class="input-field">
                                  <input class="date-input" type="text" name="h" value="<?=$_date_h;?>" >
                                  <label for="cr-date">Hasta</label>
                              </div>
                          </div>
                          <div class="col s6 m4">
                              <div class="input-field">
                                  <button type="submit" id="panel_user_search" class="btn waves-effect waves-light <?=$info->botton_color?> <?=$info->botton_color_t?> <?=$info->botton_fondo?> <?=$info->botton_tono?> col s12">Buscar</button>
                              </div>
                          </div>
                        </form>
                  		</div>
                  	</div>
			            </div>
			            <div class="col s12 l6">
			            	<div class="card animate fadeLeft">
				               <div class="card-content cyan white-text">
				                  <p class="card-stats-title"><i class="material-icons">assignment</i> Ordenes en este periodo</p>
				                  <h4 class="card-stats-number white-text"><?=array_sum($_opers);?></h4>
				                  <p class="card-stats-compare">
				                     <i class="material-icons">insert_chart</i> <?=intval(array_sum($_opers)/count($_opers));?>
				                     <span class="cyan text text-lighten-5">diarias en promedio</span>
				                  </p>
				               </div>
				               <div class="card-action cyan darken-1">
				                  <canvas class="charts" data-fondo='rgba(0, 131, 143, 0.7)' data-currency="0" data-type='bar' data-line="rgba(0, 131, 143, 1)" data-labels='<?=json_encode($_dates);?>' data-datos='<?=json_encode($_opers);?>' data-label='# ordenes' height="100"></canvas>
				               </div>
				            </div>
			            </div>
			            <div class="col s12 l6">
			            	<div class="card animate fadeRight">
				               <div class="card-content orange lighten-1 white-text">
				                  <p class="card-stats-title"><i class="material-icons">trending_up</i> Ganancias total</p>
				                  <h4 class="card-stats-number white-text"><?=sprintf('%.2f', array_sum($_profi));?> €</h4>
				                  <p class="card-stats-compare">
				                     <i class="material-icons">equalizer</i><?=sprintf('%.2f', array_sum($_profi)/count($_profi));?> €
				                     <span class="orange-text text-lighten-5">diarios en promedio</span>
				                  </p>
				               </div>
				               <div class="card-action orange">
				                  <canvas class="charts" data-fondo='rgba(239, 108, 0, 0.7)' data-currency='1' data-type='bar' data-line="rgba(239, 108, 0, 1)" data-labels='<?=json_encode($_dates);?>' data-datos='<?=json_encode($_profi);?>' data-label='# ganacias' height="100"></canvas>
				               </div>
				            </div>
			            </div>
			            <div class="col s12">
			            	<div class="card">
                  		<div class="card-content card-border-gray">
                  			<table class="datatable" data-page-length="25">
                  				<thead>
                  					<tr>
                  						<th>Fecha</th>
                  						<?=$_con?"<th># Orden</th>":"";?>
                  						<th>SKU</th>
                  						<th>Artículos</th>
                  						<th>Beneficio</th>
                  						<th>ROI</th>
                  						<th>Margen</th>
                  					</tr>
                  				</thead>
                  				<tbody>
                  					<?php foreach ($_opers_all as $op) {
                  							echo "<tr>
            											<td data-sort='$op->fecha'>". date("d/m/Y H:i", strtotime($op->fecha)) ."</td>".
            											($_con?"<td>$op->orden</td>":'')
            											."<td>$op->sku</td>
            											<td>$op->ventas</td>
            											<td>$op->beneficio €</td>
            											<td>" . number_format($op->roi,0) . "%</td>
            											<td>" . number_format($op->margen,0) . "%</td>
            										</tr>";
                  					} ?>
                  				</tbody>
                  			</table>
                  		</div>
                  	</div>
			            </div>
			        </div>
			    </div>
			</div>
		</div>
	</div>
</div>

<?php if ( in_array( 'administrator', (array) $_user->roles ) ):  ?>
  <div class="fixed-action-btn change_user"><a class="btn-floating btn-large gradient-shadow"><i class="material-icons">filter_list</i></a></div>
  <div class="modal-user">
    <div class="modal-user-cont">
      <span>X</span>
      <h4>Seleccione un usuario</h4>
      <?php $users = get_users( array( 'fields' => array( 'ID', 'display_name' ) ) ); ?>
      <select id='user_select'>
        <option value="">Todas las operaciones</option>
        <?php foreach($users as $user){
          if($_u == $user->ID){
            echo "<option selected value='$user->ID'>$user->display_name</option>";
          }else{
            echo "<option value='$user->ID'>$user->display_name</option>";
          }
        } ?>
      </select>
    </div>
  </div>
<?php endif; ?>

