<?php
/**
 * JetWooBuilder Products Grid widget loop end template.
 *
 * This template can be overridden by copying it to yourtheme/jet-woo-builder/widgets/global/products-grid/loop-end.php.
 */
?>
</div>
