import action from './RestApiAction';
import { registerAction } from 'jet-form-builder-actions';

registerAction( action );
